import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map, switchMap, take, tap } from 'rxjs/operators';
import { assign, cloneDeep, omit } from 'lodash-es';
import { Moment } from 'moment';
import { Calendar, CalendarEvent, CalendarEventEditMode, CalendarSettings, CalendarWeekday } from 'app/modules/admin/apps/calendar/calendar.types';
import { calendars as calendarsData, events as eventsData, exceptions as exceptionsData, settings as settingsData, weekdays as weekdaysData } from 'app/modules/admin/apps/calendar/data';
import * as moment from 'moment';
import { SessionService } from 'app/services/session.service';

@Injectable({
    providedIn: 'root'
})
export class CalendarService
{
    // Private
    private _calendars1: Calendar[] = calendarsData;
    private _events1: CalendarEvent[] = eventsData.map(event => ({
        ...event,
        recurringEventId: null,
        isFirstInstance: false
    }));
    private _exceptions1: any[] = exceptionsData;
    private _settings1: CalendarSettings = {
        ...settingsData,
        dateFormat: settingsData.dateFormat as "ll" | "DD/MM/YYYY" | "MM/DD/YYYY" | "YYYY-MM-DD",
        timeFormat: settingsData.timeFormat as "24" | "12",
        startWeekOn: settingsData.startWeekOn as 0 | 1 | 6
    };
    private _weekday1s: CalendarWeekday[] = weekdaysData;
    
    private _calendars: BehaviorSubject<Calendar[]> = new BehaviorSubject<Calendar[]>(this._calendars1);
    private _events: BehaviorSubject<CalendarEvent[]> = new BehaviorSubject<CalendarEvent[]>(this._events1);
    private _loadedEventsRange: { start: Moment | null; end: Moment | null } = {
        start: null,
        end: null
    };
    private readonly _numberOfDaysToPrefetch = 60;
    private _settings: BehaviorSubject<CalendarSettings> = new BehaviorSubject<CalendarSettings>(this._settings1);
    private _weekdays: BehaviorSubject<CalendarWeekday[]> = new BehaviorSubject<CalendarWeekday[]>(this._weekday1s);
    CalendarService: any;

    /**
     * Constructor
     */
    constructor(private _httpClient: HttpClient,
        public _sessionService:SessionService
    )
    {
        // No need for initialization in constructor since we're initializing in the BehaviorSubject declarations
    }


    static guid(): string
    {
        /* eslint-disable */

        let d = new Date().getTime();

        // Use high-precision timer if available
        if ( typeof performance !== 'undefined' && typeof performance.now === 'function' )
        {
            d += performance.now();
        }

        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
            const r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });

        /* eslint-enable */
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for calendars
     */
    get calendars$(): Observable<Calendar[]>
    {
        return this._calendars.asObservable();
    }

    /**
     * Getter for events
     */
    get events$(): Observable<CalendarEvent[]>
    {
        return this._events.asObservable();
    }

    /**
     * Getter for settings
     */
    get settings$(): Observable<CalendarSettings>
    {
        return this._settings.asObservable();
    }

    /**
     * Getter for weekdays
     */
    get weekdays$(): Observable<CalendarWeekday[]>
    {
        return this._weekdays.asObservable();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Get calendars
     */
    getCalendars(UserID): Observable<Calendar[]>
    {
        this.getUserevents(UserID);
        return of(this._calendars1).pipe(
            tap(calendars => {
                this._calendars.next(calendars);
            })
        );

    }

    /**
     * Add calendar
     *
     * @param calendar
     */
    addCalendar(calendar: Calendar): Observable<Calendar>
    {
        const newCalendar = cloneDeep(calendar);
        newCalendar.id = CalendarService.guid();
        
        return this.calendars$.pipe(
            take(1),
            map(calendars => {
                // Add the calendar
                calendars.push(newCalendar);
                
                // Update the calendars
                this._calendars.next(calendars);
                
                // Return the added calendar
                return newCalendar;
            })
        );
    }

    /**
     * Update calendar
     *
     * @param id
     * @param calendar
     */
    updateCalendar(id: string, calendar: Calendar): Observable<Calendar>
    {
        return this.calendars$.pipe(
            take(1),
            map(calendars => {
                // Find the index of the updated calendar
                const index = calendars.findIndex(item => item.id === id);

                // Create updated calendar by merging existing with updates
                const updatedCalendar = {...calendars[index], ...calendar};

                // Update the calendar
                calendars[index] = updatedCalendar;

                // Update the calendars
                this._calendars.next(calendars);

                // Return the updated calendar
                return updatedCalendar;
            })
        );
    }

    /**
     * Delete calendar
     *
     * @param id
     */
    deleteCalendar(id: string): Observable<boolean>
    {
        return this.calendars$.pipe(
            take(1),
            map(calendars => {
                // Find the index of the deleted calendar
                const index = calendars.findIndex(item => item.id === id);

                // Delete the calendar
                calendars.splice(index, 1);

                // Update the calendars
                this._calendars.next(calendars);

                // Remove the events belong to deleted calendar
                const events = this._events.value.filter(event => event.calendarId !== id);

                // Update the events
                this._events.next(events);

                // Return success
                return true;
            })
        );
    }

    /**
     * Get events
     *
     * @param start
     * @param end
     * @param replace
     */
    getEvents(start: Moment, end: Moment, replace = false): Observable<CalendarEvent[]>
    {
        // Set the new start date for loaded events
        if (replace || !this._loadedEventsRange.start || start.isBefore(this._loadedEventsRange.start)) {
            this._loadedEventsRange.start = start;
        }

        // Set the new end date for loaded events
        if (replace || !this._loadedEventsRange.end || end.isAfter(this._loadedEventsRange.end)) {
            this._loadedEventsRange.end = end;
        }

        // Filter events based on date range
        const filteredEvents = this._events1.filter(event => {
            const eventStart = moment(event.start);
            const eventEnd = moment(event.end);
            return eventStart.isBetween(start, end, 'day', '[]') || 
                   eventEnd.isBetween(start, end, 'day', '[]');
        });

        // Update the events subject
        if (replace) {
            this._events.next(filteredEvents);
        } else {
            const currentEvents = this._events.getValue() || [];
            this._events.next([...currentEvents, ...filteredEvents]);
        }
console.log("--------------filtered data-----------",filteredEvents)
        // Return the filtered events
        return of(filteredEvents);
    }

    /**
     * Reload events using the loaded events range
     */
    reloadEvents(): Observable<CalendarEvent[]>
    {
        return of(this._events1).pipe(
            map((response) => {
                this._events.next(response);
                return response;
            })
        );
    }

    /**
     * Prefetch future events
     *
     * @param end
     */
    prefetchFutureEvents(end: Moment): Observable<CalendarEvent[]>
    {
        // Calculate the remaining prefetched days
        const remainingDays = this._loadedEventsRange.end.diff(end, 'days');

        // Return if remaining days is bigger than the number
        // of days to prefetch. This means we were already been
        // there and fetched the events data so no need for doing
        // it again.
        if ( remainingDays >= this._numberOfDaysToPrefetch )
        {
            return of([]);
        }

        // Figure out the start and end dates
        const start = this._loadedEventsRange.end.clone().add(1, 'day');
        end = this._loadedEventsRange.end.clone().add(this._numberOfDaysToPrefetch - remainingDays, 'days');

        // Prefetch the events
        return this.getEvents(start, end);
    }

    /**
     * Prefetch past events
     *
     * @param start
     */
    prefetchPastEvents(start: Moment): Observable<CalendarEvent[]>
    {
        // Calculate the remaining prefetched days
        const remainingDays = start.diff(this._loadedEventsRange.start, 'days');

        // Return if remaining days is bigger than the number
        // of days to prefetch. This means we were already been
        // there and fetched the events data so no need for doing
        // it again.
        if ( remainingDays >= this._numberOfDaysToPrefetch )
        {
            return of([]);
        }

        // Figure out the start and end dates
        start = this._loadedEventsRange.start.clone().subtract(this._numberOfDaysToPrefetch - remainingDays, 'days');
        const end = this._loadedEventsRange.start.clone().subtract(1, 'day');

        // Prefetch the events
        return this.getEvents(start, end);
    }

    /**
     * Add event
     *
     * @param event
     */
    addEvent(event): Observable<CalendarEvent>
    {
        // this._sessionService.getEventDetails(event).subscribe(async(response:any)=>{
        //     console.log("Event Details:", response);
 
         

        // })
       
        return this.events$.pipe(
            take(1),
            map(events => {
                const newEvent = {
                    ...event,
                    id: CalendarService.guid()
                };
                this._events1.push(newEvent);
                events = events || [];
                this._events.next([...events, newEvent]);
                return newEvent;
            })
        );

    }

    /**
     * Update event
     *
     * @param id
     * @param event
     */
    updateEvent(id: string, event): Observable<CalendarEvent>
    {
        return this.events$.pipe(
            take(1),
            map(events => {
                const index = events.findIndex(item => item.id === id);
                const updatedEvent = { ...events[index], ...event };
                events[index] = updatedEvent;
                this._events.next(events);
                return updatedEvent;
            })
        );
    }

    /**
     * Update recurring event
     *
     * @param event
     * @param originalEvent
     * @param mode
     */
    updateRecurringEvent(event, originalEvent, mode: CalendarEventEditMode): Observable<boolean>
    {
        // Implement recurring event logic here based on mode
        return of(true).pipe(
            map(() => {
                const events = this._events.value || [];
                if (mode === 'single') {
                    // Update single occurrence
                    const index = events.findIndex(e => e.id === event.id);
                    if (index !== -1) {
                        events[index] = event;
                    }
                } else if (mode === 'future') {
                    // Update this and future occurrences
                    const futureEvents = events.filter(e => 
                        e.recurringEventId === originalEvent.recurringEventId && 
                        e.start >= originalEvent.start
                    );
                    futureEvents.forEach(e => {
                        const index = events.findIndex(ev => ev.id === e.id);
                        events[index] = { ...e, ...event };
                    });
                } else if (mode === 'all') {
                    // Update all occurrences
                    const allEvents = events.filter(e => 
                        e.recurringEventId === originalEvent.recurringEventId
                    );
                    allEvents.forEach(e => {
                        const index = events.findIndex(ev => ev.id === e.id);
                        events[index] = { ...e, ...event };
                    });
                }
                this._events.next(events);
                return true;
            })
        );
    }

    /**
     * Delete event
     *
     * @param id
     */
    deleteEvent(id: string): Observable<boolean>
    {
        return this.events$.pipe(
            take(1),
            map(events => {
                const index = events.findIndex(item => item.id === id);
                events.splice(index, 1);
                this._events.next(events);
                return true;
            })
        );
    }

    /**
     * Delete recurring event
     *
     * @param event
     * @param mode
     */
    deleteRecurringEvent(event, mode: CalendarEventEditMode): Observable<boolean>
    {
        return of(true).pipe(
            map(() => {
                const events = this._events.value || [];
                if (mode === 'single') {
                    // Delete single occurrence
                    const index = events.findIndex(e => e.id === event.id);
                    if (index !== -1) {
                        events.splice(index, 1);
                    }
                } else if (mode === 'future') {
                    // Delete this and future occurrences
                    const filteredEvents = events.filter(e => 
                        !(e.recurringEventId === event.recurringEventId && 
                        e.start >= event.start)
                    );
                    this._events.next(filteredEvents);
                } else if (mode === 'all') {
                    // Delete all occurrences
                    const filteredEvents = events.filter(e => 
                        e.recurringEventId !== event.recurringEventId
                    );
                    this._events.next(filteredEvents);
                }
                return true;
            })
        );
    }

    /**
     * Get settings
     */
    getSettings(): Observable<CalendarSettings> {
        return of(this._settings1).pipe(
            tap(settings => {
                this._settings.next(settings);
            })
        );
    }

    /**
     * Update settings
     */
    updateSettings(settings: CalendarSettings): Observable<CalendarSettings>
    {
        return this.events$.pipe(
            take(1),
            map(() => {
                // Update the settings
                this._settings1 = settings;
                this._settings.next(settings);

                // Get weekdays again to get them in correct order
                // in case the startWeekOn setting changes
                this.getWeekdays().subscribe();

                // Return the updated settings
                return settings;
            })
        );
    }

    /**
     * Get weekdays
     */
    getWeekdays(): Observable<CalendarWeekday[]> {
        return of(this._weekday1s).pipe(
            tap(weekdays => {
                this._weekdays.next(weekdays);
            })
        );
    }


    
    getUserevents(UserID) {
        this._sessionService.getUserevents(UserID).subscribe(async (response: any) => {
            console.log(response.entity.data)
            if (response.entity.data.length>0) {
                let events=(response.entity.data) 
                // const currentEvents = this._events.getValue() || [];
                // this._events.next([...currentEvents, ...events]);            
                this._events.next([...events]);
            }
        });
    }
}
